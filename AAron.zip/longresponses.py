import random

R_EATING = " I dont like Eating anything because I'm a bot you fucking fool!"


def unknown():
    response = ['could you please re-phrase that?', "...", "sounds about right",
    "what does that mean"][random.randrange(4)]
    
    return response
