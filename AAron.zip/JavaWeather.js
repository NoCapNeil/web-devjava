<html lang="en" dir ="ltr">
<head>
    <meta charset= "utf-8">
        <title>Alarm Clock | codingNepal</title>
        <link rel="stylesheet" href="style.css"></link>
        <meta name= "viewport" content "width=device-width, initial-scale=1.0">
</head>
<body></body>
</html>