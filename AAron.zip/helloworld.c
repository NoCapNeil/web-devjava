#inculde <stdio>
#include <stdlib>

int main(){
    printf"hello world!";





}
return (0)